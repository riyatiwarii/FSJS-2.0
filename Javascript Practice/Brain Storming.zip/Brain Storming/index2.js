let a = 10;
let b = a; //10
a = 5;
console.log(`a is : ${a}`)
console.log(`b is : ${b}`)

const mayurIntro = {
    myName : "Mayur",
    salary : "2.5k USD",
}
const bharatIntro = mayurIntro
console.log(mayurIntro)
console.log(bharatIntro)
bharatIntro.salary = "500K USD"
console.log(mayurIntro)
console.log(bharatIntro)
 console.log(mayurIntro === bharatIntro)
 const p = [];
const q = [];
const r = p;
console.log(p === q)
console.log(p === r)