//type coercion -- 

//mathematical operators
//additional oprator
//+ = operator and operands
let str = '2'+3;
// str = '2+ String(3)
// console.log(typeof str, str);

//Substraction - 
let num = "23"-10;
// num = Number("23")-10
// console.log(num, typeof num);

//* same as minus operator

// division - same as minus operator

//remainder % -same as minus operator

// console.log(2 + 6 + "15" -3 );
//8+'15'-3
//'815'-3
// 812


//Booleans
//falsy value --> 0, null, undefined, NaN, ""
console.log(Boolean(""));
console.log(Boolean(0));
console.log(Boolean(null));
console.log(Boolean(undefined));
console.log(Boolean(NaN));



//Truthy value --> Rest are Truthy values
console.log(Boolean("savinder"));
console.log(Boolean(15));
console.log(Boolean([]));
console.log(Boolean({}));
console.log(Boolean(" "));

if (556+"kfkj"){
    console.log("If block is executed")

}else{
    console.log("else block is executed")
}


//string comparison
const str1 = "riya";
const str2 = "rayur";
console.log("r".charCodeAt())
console.log("i".charCodeAt())
console.log("a".charCodeAt())
// console.log(str1>str2);

// ==(loose) vs ===(strict)
console.log(2 == '2')  // type coercion will work
console.log(2 === '2') // type coercion will not work;

//Number() or unary operator

console.log(Number("20"), typeof (Number("20")))
console.log(+"20", typeof +"20");