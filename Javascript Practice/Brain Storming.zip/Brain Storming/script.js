//JavaScript Function


//Function syntax 
/*function sayHello () {
    console.log("Hey! Hello from JavaScript");
}

sayHello ();
sayHello ();
sayHello ();
sayHello ();
sayHello ();*/

// Function Declaration aka Function statement aka classic function
// Function Expression
// Arrow functions

// Statement vs Expression
//Expression- piece of code but it will produce some value
//5+6--> 
//true && f11alse --> false 
// "bharat"

//Statement --> piece of code but will won't produce any value, it will perform some actions
// const myName = "xyz"


//Template string always allows expression
// console.log( `Hello! My name is ${"savinder"}`) // allowed

// console.log( `Hello! My name is ${const a = 10;}`) // not allowed


// if( 56-53 ){
//     console.log("if block executed")
// }

// if( const a = 10; ){
//     console.log("if block executed")

// }


// Function Declaration aka Function statement aka classic function

function orangeCutter(oranges) {
    const orangePieces = oranges * 4;
    return orangePieces;
}
function appleCutter(apples) {
    const applesPiece = apples * 2;
    return applesPiece;
}

function juicer(oranges, apples) {
const orangePieces = orangeCutter(oranges) //40
const applePiece = appleCutter(apples); //10
// function hello (){
//     return "I am inside juicer function"
// }
return `Oranges have ${orangePieces} pieces and Apples have ${applePiece}`;
}

//Invoke/run/call

const morningJuice = juicer(10, 5);
console.log(morningJuice)
// console.log(hello()); // error

//********************/ */

// var x =10;
// function num (n){
// var x = n+n;
// return x;
// }
// var num2 = num(x);
// console.log(num2)
// console.log(x);

// Function expression


console.log(fun2)
// console.log(fun2())
var fun2 = function (){
    console.log(`fun2 is executed`);
}
const a = fun2();
console.log(a)

/* function () {
    //
} */

// fun3()
// function fun3 () {
//     console.log("fun3 is called")
// }

// fun3();
